<?php
include_once('../config.php');
if(!empty($_GET))
{
$directory = $dashbard_database_path."customers/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}


$files = glob($directory."*.json");
$newDataArray = array();
foreach($files as $file){
    $thisData = file_get_contents($file);
    $thisDataArray = json_decode($thisData);
    $newDataArray[] = $thisDataArray;
}
$code = $newDataArray;
if(empty($code)){
$cc = json_encode(array());
echo $cc;
exit;	
	
}else{
$cc = json_encode($code);
echo $cc;
exit;
}

}else{
$msg = "Request Not Understood";
$cc = json_encode(array());
echo $cc;
exit;
}

?>