<?php
include "../config.php";
if(!empty($_POST["email"])){
$mailto = $_POST['email'];
      $subject = $_POST['msub'];
      $message = $_POST['minfo'];
      $header  = "From: no_reply@".@$_SERVER['HTTP_HOST']."\r\n";
      $header .= "Reply-To: no_reply@".@$_SERVER['HTTP_HOST']."\r\n";
      $header .= "MIME-Version: 1.0"."\r\n";
      $header .= "Content-Type: text/plain; charset=utf-8"."\r\n";
      $header .= "Content-Transfer-Encoding: 8bit"."\r\n";
      $header .= "X-Mailer: PHP v".phpversion();
      mail($mailto, $subject, $message, $header);
$cc = json_encode(array("status" => "Success","code" => "200","message" => "Message Sent Successfully","rtype" => "msg"));
echo $cc;
exit;	
}	
?>
<div class='main-container'>
<div class="container-fluid bg-light pb-5 pt-5">
<div class="modal-content p-4 pb-4 pt-4">

<div class="border-bottom mb-3 row">
<div class="col"><h4><span class="btn btn-primary" onClick="$('.all').hide();$('.customers').show();"><i class="fa fa-angle-left"></i>&nbsp;&nbsp;Back</span></h4></div>
<div class="col text-center"><h4><b>&nbsp;&nbsp;Send Mail</b></h4></div>
<div class="col text-right"></div>
</div>
<div class="formspec">
    <form class="modal-content" method="post" id="msg_form2">
          <div class="modal-body">
		  <div class="form-group">
          <input class="form-control" id="rname" name="rname" type="text" placeholder="Reciever Name" data-validation="required" data-validation-error-msg="Reciever Name is required">
		  <input class="form-control" name="email" id="email" type="hidden">
        </div>
        <div class="form-group">
        <input class="form-control"  name="msub" id="msub" type="text" placeholder="Mssage Subject" data-validation="required" data-validation-error-msg="Subject is required">
        </div>
        <div class="form-group">
		<textarea class="form-control"  id="minfo" name="minfo"  placeholder="What is in your mind"></textarea>
        </div>

      </div>
          <div class="modal-footer ">
        <button type="submit" class="btn btn-primary" ><span class="fa fa-paper-plane"></span>&nbsp;&nbsp;Process</button>
		 
      </div>
        </form>
        
  </div>
  
  </div>	
</div>	
</div>
  <script>
$.validate({
    form : '#msg_form2',
    modules : 'security',
	onError : function($form) {
		$("#snackbar").html("Form Validation Failed");
myswagFunction();
	  return false; // Will stop the submission of the form
    },
    onSuccess : function($form) {
	if($form.attr('id') == "msg_form2")
	{
	$(".pagecontent").hide();
	$(".loader").show();
	Processclass()
	}
    return false; // Will stop the submission of the form
    },
  });
function Processclass()
   {
var ur1 =  "./sendmessage2.php";
var method = "POST";
$.ajax({
    type: method,
    url: ur1,
    data:  $('#msg_form2').serialize() + "&form_name=sendmessage&rnd=" + String((new Date()).getTime()).replace(/\D/gi, ''), // access in body
}).done(function (data) {
data = JSON.parse(data);
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html(data.message);
myswagFunction();
}).fail(function (error) {
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html("Request Not Processed");
myswagFunction();
}).always(function (cdata) {
});
     
    
   }  

</script>

