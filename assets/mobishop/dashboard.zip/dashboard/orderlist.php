<?php
include "../config.php";
$settings	=  json_decode(file_get_contents($dashbard_database_path."settings/data.json"), true);
$order	=  json_decode(file_get_contents($dashbard_database_path."orders/".$_GET["orderid"].".json"), true);
?>
<div class='main-container'>
<div class="container-fluid bg-light pb-5 pt-5">
<div class="modal-content p-4 pb-4 pt-4">

<div class="border-bottom mb-3 row">
<div class="col"><h4><span class="btn btn-primary" onClick="$('.all').hide();$('.sales').show();"><i class="fa fa-angle-left"></i>&nbsp;&nbsp;Back</span></h4></div>
<div class="col text-center"><h4><b>&nbsp;&nbsp;Order Invoice</b></h4></div>
<div class="col text-right"><h4><span class="btn btn-primary print-in"><i class="fa fa-print"></i>&nbsp;&nbsp;print</span></h4></div>
</div>
<div class="formspec">
    <div class="modal-content">
          <div class="modal-body">
		  
		  
		  
		  
		  
		  
		  <div id="shopping-cart">
<?php
if(!empty($order)){
    $total_quantity = 0;
    $total_price = 0;
	$total_vat = 0;
	$total_shipping = 0;
?>	
<table class="table" cellpadding="10" cellspacing="1" width="100%">
<thead>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:right;" width="5%">Qty</th>
<th style="text-align:right;" width="15%">Price</th>
<th style="text-align:right;" width="15%">Total</th>
</tr>
</thead>	
<tbody>
<?php		
    foreach ($order as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
				<tr>
				<td><?php echo $item["pname"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo $settings["picon"]."".number_format($item["price"],2); ?></td>
				<td  style="text-align:right;"><?php echo $settings["picon"]."". number_format($item_price,2); ?></td>
				</tr>
				<?php
				$total_vat += $item["vat"]*$item["quantity"];
				$total_shipping += ($item["shipping"]*$item["quantity"]);
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>
<?php
if($total_vat > 0){
?>
<tr>
<td align="right" colspan="5"><strong>Vat:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $settings["picon"]."".number_format($total_vat, 2); ?></strong></td>
</tr>
<?php
}
?>
<?php
if($total_shipping > 0){
if($total_price > $settings["fsa"]){
$total_shipping = 0.00;
}elseif($total_shipping > $settings["msc"]){
$total_shipping = $settings["msc"];
}
?>
<tr>
<td align="right" colspan="5"><strong>Shipping:&nbsp;&nbsp;&nbsp;<?php echo $settings["picon"]."".number_format($total_shipping, 2); ?></strong></td>
</tr>
<?php
if($settings["ptax"] == "In.vat"){
$total_price = 	$total_price + $total_vat;
$tot = $settings["ptax"];
}elseif($settings["ptax"] == "Ex.vat"){
$tot = $settings["ptax"];
}else{
$tot = "";	
}
}
?>
<tr>
<td align="right" colspan="5"><strong>Total:&nbsp;&nbsp;&nbsp;<?php echo $settings["picon"]."".number_format($total_price, 2); ?>&nbsp;&nbsp;<span style="color: red"><?php echo $tot; ?></span></strong></td>

</tr>
</tbody>
</table>
  <?php
}
?>


</div>
		
		
		
		
		
		

      </div>
          
        </div>
        
  </div>
  
  </div>	
</div>	
</div>
  <script>
$(document).on('click', '.print-in', function() {
   w=window.open();
w.document.write($('#shopping-cart').html());
w.print();
w.close();
  });

</script>

