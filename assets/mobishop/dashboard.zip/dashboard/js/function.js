function myswagFunction() {
$('#snackbar').addClass('show');
    setTimeout(function(){ $('#snackbar').removeClass('show'); }, 3000);
}
$.fn.dataTable.ext.errMode = 'none';
   var table1 =  $('#datatable1').DataTable({ 
	  "ajax":{
        "url":"./productlist.php?rnd=" + String((new Date()).getTime()).replace(/\D/gi, ''),
 "contentType":"application/json; charset=utf-8",
      "dataType":"json",
        "dataSrc": function ( json ) { 
		var valuesparent = $.map( json, function (value, key) { return value; });
        return valuesparent;
		  },
	"error": function (error) { 
		  }, 
      },
        "columns": [
		{ "data": "pname" ,"defaultContent": "Not set"  },
			{ "data": "code" ,"defaultContent": "Not set"  },
			{ "data": "price" ,"defaultContent": "Not set"  },
			{ "data": "pdate" ,"defaultContent": "Not set"  },
			{ "data": "ptax" ,"defaultContent": "Not set"  },
			{ "data": "pshipping" ,"defaultContent": "Not set"  },
			{ "data": "pstatus" ,"defaultContent": "Not set"  },
			{ "data": "pstock" ,"defaultContent": "Not set"  },
			{ "data": "description" ,"defaultContent": "Not set"  },
						{ "data": "code" ,"defaultContent": "Not set"  },
        ],
		"columnDefs": [ {
    "targets": 9,
    "data": "download_link",
    "render": function ( data, type, row, meta ) {
	  return '<a class="btn dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b><i class="fa fa-indent"></i></b></a><div class="dropdown-menu" aria-labelledby="navbarDropdown"><a class="dropdown-item updateproduct" href="#" title="Update Product"><i class="fa fa-edit text-blue"></i>&nbsp;&nbsp;Update Product</a>';
		
	}
  }],
		deferRender: true,
		responsive: true,
		"autoWidth": false,
		dom: 'Bfrtip',
        buttons: [
        'pdf',
        'excel',
        'print'
    ]
		
  });
 
	
 $('#datatable1 tbody').on('click', '.updateproduct', function (element) {
var tr = $(element.target).closest('tr');
        if(tr.hasClass('child'))
        {
            tr=$(tr).prev();
        }
        var datat = table1.row(tr).data();
		$(".pagecontent").empty();
		 $("#loader").show();
$(".pagecontent").load("./mproduct.php",function(){
		$("#pname").val(datat["pname"]);
		$("#pprice").val(datat["price"]);
		$("#pstatus").val(datat["pstatus"]);
		$("#pstock").val(datat["pstock"]);
		$("#ptax").val(datat["ptax"]);
		$("#pshipping").val(datat["pshipping"]);
		$("#description").val(datat["description"]);
		$("#pcode").val(datat["code"]); 
		$("#pdate").val(datat["pdate"]); 
		$("#digit-d").val(datat["digit-d"]); 
		$(".all").hide();
		$(".pagecontent").show();
		$(".loader").hide();
    } );
    } ); 

$(document).on("click", ".newlink", function(event){
 $(".loader").show();
 var linka = $(this);
            $(".pagecontent").empty();
            $(".pagecontent").load(this.id, function( response, status, xhr ) {
           if ( status == "error" ) {
           $(".loader").hide();
           $('#snackbar').html("The Requested Module Could Not Be Loaded");
		   myswagFunction();
           return false;
           }else{
		    $('a.active').removeClass('actice');
linka.addClass('active');
		   $(".all").hide();
        $(".loader").hide();
           $(".pagecontent").show();
           return false;
            }
           });
event.preventDefault();
          });	