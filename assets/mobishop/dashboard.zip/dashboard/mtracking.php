<?php
include "../config.php";
$order	=  json_decode(file_get_contents($dashbard_database_path."sales/".$_GET["orderid"].".json"), true);
$track	=  @file_get_contents($dashbard_database_path."track/".$_GET["orderid"].".txt");
if(!empty($_POST)){	
$directory = $dashbard_database_path."track/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}

$proid = $_POST["pcode"];
$pdate = @date("d/m/Y s:m:h");
$msg = "Product Track Have Been Updated Successfully";
file_put_contents($directory.$proid.".txt", @$_POST["track"]);
$cc = json_encode(array("status" => "Success","code" => "200","message" => $msg,"rtype" => "mproduct"));
echo $cc;
exit;
}
?>
<div class="border-bottom mb-3 row">
<div class="col"><h4><span class="btn btn-primary" onClick="$('.all').hide();$('.sales').show();"><i class="fa fa-angle-left"></i>&nbsp;&nbsp;Back</span></h4></div>
<div class="col text-center"><h4><b>&nbsp;&nbsp;Manage Track</b></h4></div>
<div class="col text-right"></div>
</div>
    <form class="modal-content" method="post" id="track_form">
          <div class="modal-body">
		<div class="form-group">
		<input class="form-control" name="pcode" id="pcode" type="hidden" value="<?php echo @$order["code"]; ?>">
		<textarea class="form-control" id="tracking" name="track" placeholder="Tracking Information" data-validation="required" data-validation-error-msg="Tracking Information is Needed"><?php echo @$track; ?></textarea>
        </div>	
      </div>
          <div class="modal-footer ">
      <button type="submit" class="btn btn-primary" ><span class="fa fa-paper-plane"></span>&nbsp;&nbsp;Process</button>
      </div>
        </form>
        
   <script>
$.validate({
    form : '#track_form',
    modules : 'security',
	onError : function($form) {
		$("#snackbar").html("Form Validation Failed");
myswagFunction();
	  return false; // Will stop the submission of the form
    },
    onSuccess : function($form) {
	if($form.attr('id') == "track_form")
	{
	$(".pagecontent").hide();
	$(".loader").show();
	Processclass()	
	}
    return false; // Will stop the submission of the form
    },
  });
function Processclass()
   {   
$("#tracking").val($(".nicEdit-main").html());
var ur1 = "mtracking.php";
var method = "POST";
$.ajax({
    type: method,
    url: ur1,
    data:  $('#track_form').serialize() + "&form_name=mtrack&rnd=" + String((new Date()).getTime()).replace(/\D/gi, ''), // access in body
}).done(function (data) {
data = JSON.parse(data);
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html(data.message);
myswagFunction();
}).fail(function (error) {
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html("Request Not Processed");
myswagFunction();
}).always(function (cdata) {
});
     
    
   }  
   $(document).ready(function(){
	 var area1;
function toggleArea1() {
	if(!area1) {
		area1 = new nicEditor({fullPanel : true, onSave : function(content, id, instance) {
    alert('save button clicked for element '+id+' = '+content);
  } }).panelInstance('tracking',{hasPanel : true});
	} else {
		area1.removeInstance('tracking');
		area1 = null;
	}
}    
	toggleArea1()
	});
</script>