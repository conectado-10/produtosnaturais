<?php
require_once("../config.php");
$payment_api	= file_get_contents("../payment_processor/list.json");
$directory = $dashbard_database_path."sales/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}
$datainfo	= json_decode(file_get_contents($directory.$_GET["salesid"].".json"), true);
if(!empty($_POST)){	
$msg = "Sales Updated Successfully";
$submitdata = array('code'=>$_POST["pcode"], 'amount'=>$_POST["amt"], 'status'=>$_POST["pstatus"], 'day'=>$_POST["day"],'pro'=>$_POST["papi"],'pcode'=>$_POST["procode"],'cname'=>$_POST["cname"], 'phone'=>$_POST["phone"], 'email'=>$_POST["email"], 'add'=>$_POST["cadd"]);
$encode_data = json_encode($submitdata);
file_put_contents($directory.$_POST["pcode"].".json", $encode_data);
$cc = json_encode(array("status" => "Success","code" => "200","message" => $msg,"rtype" => "settings"));
echo $cc;
exit;
}
?>
<div class="border-bottom mb-3 row">
<div class="col"><h4><span class="btn btn-primary" onClick="$('.all').hide();$('.sales').show();"><i class="fa fa-angle-left"></i>&nbsp;&nbsp;Back</span></h4></div>
<div class="col text-center"><h4><b>Manage Sales</b></h4></div>
<div class="col text-right"></div>
</div>
    <form class="modal-content" method="post" id="sales_form">
          <div class="modal-body">
		<div class="form-group">
        <input class="form-control" id="cname" name="cname" type="text" placeholder="Customer's Fullname" data-validation="required"  data-validation-error-msg="Provide Customer's Fullname" value="<?php echo @$datainfo["cname"];?>">
        </div>
		<div class="form-group">
        <input class="form-control" id="phone" name="phone" type="text" placeholder="Customer's Phone Number" data-validation="custom" data-validation-regexp="^([0-9]+)$" data-validation-error-msg="Provide a valid phone number" value="<?php echo @$datainfo["phone"];?>">
        </div>
		<div class="form-group">
        <input class="form-control" id="email" name="email" type="email" placeholder="Customer's Email Address" data-validation="email" data-validation-error-msg="Provide a valid email" value="<?php echo @$datainfo["email"];?>">
        </div>
		<div class="form-group">
        <input class="form-control" id="cadd" name="cadd" type="text" placeholder="Customer's Address" data-validation="required"  data-validation-error-msg="Provide Customer's Address" value="<?php echo @$datainfo["add"];?>">
        </div>
		<div class="form-group">
        <input class="form-control" id="amt" name="amt" type="text" placeholder="Order Total Amount" data-validation="custom" data-validation-regexp="^([0-9.]+)$" data-validation-error-msg="Provide a numeric value" value="<?php echo @$datainfo["amount"];?>">
        </div>
		<div class="form-group">
        <select class="form-control " name="pstatus" id="pstatus" placeholder="Payment Status" data-validation="required" data-validation-error-msg="Select Payment Status">
		<option value="">Payment Status</option>
		<option value="Paid"<?php echo ($datainfo["status"] == "Paid" ? "selected" : '');?>>Paid</option>
        <option value="Not paid"<?php echo ($datainfo["status"] == "Not paid" ? "selected" : '');?>>Not Paid</option>
        </select>
        </div>
		 <div class="form-group">
        <select class="form-control " name="procode" id="procode" placeholder="Currency name" data-validation="required" data-validation-error-msg="Choose Currency Icon">
		<option value="">Currency Icon</option>
        <option value="USD"<?php echo ($datainfo["pcode"] == "USD" ? "selected" : '');?>>USD</option>
        <option value="EUR"<?php echo ($datainfo["pcode"] == "EUR" ? "selected" : '');?>>EUR</option>
		<option value="GBP"<?php echo ($datainfo["pcode"] == "GBP" ? "selected" : '');?>>GBP</option>
		<option value="NGN"<?php echo ($datainfo["pcode"] == "NGN" ? "selected" : '');?>>NGN</option>
		<option value="ZAR"<?php echo ($datainfo["pcode"] == "ZAR" ? "selected" : '');?>>ZAR</option>
        </select>
		<input class="form-control" name="day" id="day" type="hidden" value="<?php echo @$datainfo["day"];?>">
		<input class="form-control" name="pcode" id="pcode" type="hidden" value="<?php echo @$datainfo["code"];?>">
        </div>
		<div class="form-group">
        <select class="form-control"  name="papi" id="papi" data-validation="required" data-validation-error-msg="Choose a Payment Processor">
		<option value="">Payment Processor</option>
		<?php 
		$payment_api = json_decode($payment_api, true);
		foreach($payment_api as $item)
{
		?>
        <option value="<?php echo $item["name"];?>"<?php echo ($datainfo["pro"] == $item["name"] ? "selected" : '');?>><?php echo $item["name"] ." payment processor";?></option>
		<?php
		}
		?>
        </select>
        </div>
      </div>
          <div class="modal-footer ">
      <button type="submit" class="btn btn-primary" ><span class="fa fa-paper-plane"></span>&nbsp;&nbsp;Process</button>
      </div>
        </form>
        
   <script>
$.validate({
    form : '#sales_form',
    modules : 'security',
	onError : function($form) {
		$("#snackbar").html("Form Validation Failed");
myswagFunction();
	  return false; // Will stop the submission of the form
    },
    onSuccess : function($form) {
	if($form.attr('id') == "sales_form")
	{
	$(".pagecontent").hide();
	$(".loader").show();
	Processclass()	
	}
    return false; // Will stop the submission of the form
    },
  });
function Processclass()
   {
var ur1 = "msales.php";
var method = "POST";
$.ajax({
    type: method,
    url: ur1,
    data:  $('#sales_form').serialize() + "&form_name=mclass&rnd=" + String((new Date()).getTime()).replace(/\D/gi, ''), // access in body
}).done(function (data) {
data = JSON.parse(data);
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html(data.message);
myswagFunction();
}).fail(function (error) {
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html("Request Not Processed");
myswagFunction();
}).always(function (cdata) {
});
     
    
   }    
</script>