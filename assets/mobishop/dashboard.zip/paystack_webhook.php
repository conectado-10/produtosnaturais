<?php
// only a post with paystack signature header gets our attention
if ((strtoupper($_SERVER['REQUEST_METHOD']) != 'POST' ) || !array_key_exists('HTTP_X_PAYSTACK_SIGNATURE', $_SERVER) ) 
    exit();

// Retrieve the request's body
$input = @file_get_contents("php://input");
define('PAYSTACK_SECRET_KEY',$paystack_secret_key);

// validate event do all at once to avoid timing attack
if($_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] !== hash_hmac('sha512', $input, PAYSTACK_SECRET_KEY))
  exit();

http_response_code(200);

// parse event (which is json string) as object
// Do something - that will not take long - with $event
$event = json_decode($input, true);


// parse event (which is json string) as object

// Do something - that will not take long - with $event
$directory = $cart_database_path."sales/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}

$transid = $event["data"]["reference"];
$sales = $directory.$transid.".json";
$salesByCode = json_decode(file_get_contents($sales), true);
$string = $salesByCode["amount"];
$stackamt = str_replace('.', '', $string);
if($event["data"]["amount"] == $stackamt){
$thisSales = array('code'=>$transid, 'amount'=>$salesByCode["amount"], 'status'=>"Paid", 'day'=>$salesByCode["day"],'pro'=>$salesByCode["pro"],'pcode'=>$salesByCode["pcode"],'cname'=>$salesByCode["cname"], 'phone'=>$salesByCode["phone"], 'email'=>$salesByCode["email"], 'add'=>$salesByCode["add"]);
$thisSales = json_encode($thisSales);
file_put_contents($directory.$transid.".json",$thisSales);
$dtnow = @date('d/m/Y h:i:s A');
$trackinfo = "<hr><p><b>".$dtnow." :&nbsp;</b>A Payment  of ".@$salesByCode['pcode'].number_format($salesByCode["amount"], 2)." was recieved Via Our  ".@$salesByCode["pro"]." payment processor Terminal.</p><hr>";
file_put_contents($cart_database_path."track/".$transid.".txt", $trackinfo, FILE_APPEND);
$order	=  json_decode(file_get_contents($cart_database_path."orders/".$transid.".json"), true);
foreach ($order as $item){
$product	=  json_decode(file_get_contents($cart_database_path."products/".$item['code'].".json"), true);	
if($product["digital-d"] != "")
{
$dtnow = @date('d/m/Y h:i:s A');
$trackinfo = "<hr><p><b>".$dtnow." :&nbsp;</b>".$product["pname"]." Was enabled for you to download. <a target='_blank' href='".$product['digital-d']."'>Click Here to start downloading</a>.</p><hr>";
file_put_contents($cart_database_path."track/".$transid.".txt", $trackinfo, FILE_APPEND);	
}
}
exit();
}
?>
