<?php
// Check to see there are posted variables coming into the script
if ($_SERVER['REQUEST_METHOD'] != "POST")
    die("No Post Variables");
// Initialize the $req variable and add CMD key value pair
$req = 'cmd=_notify-validate';
// Read the post from PayPal
foreach ($_POST as $key => $value) {
    $value = urlencode(stripslashes($value));
    $req .= "&$key=$value";
}

// Now Post all of that back to PayPal's server using curl, and validate everything with PayPal
// We will use CURL instead of PHP for this for a more universally operable script (fsockopen has issues on some environments)
//$url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
$url = $paypal_url;
$curl_result = $curl_err = '';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/x-www-form-urlencoded", "Content-Length: " . strlen($req)));
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
$curl_result = @curl_exec($ch);
$curl_err = curl_error($ch);
curl_close($ch);

$req = str_replace("&", "\n", $req);  // Make it a nice list in case we want to email it to ourselves for reporting
// Check that the result verifies
if (strpos($curl_result, "VERIFIED") !== false) {
    $req .= "\n\nPaypal Verified OK";
} else {
    $req .= "\n\nData NOT verified from Paypal!";
    exit();
}

/* CHECK THESE 2 THINGS BEFORE PROCESSING THE TRANSACTION, HANDLE THEM AS YOU WISH
  1. Make sure that business email returned is your business email
  2. Make sure that the transactions payment status is completed
 */

// Check Number 1 ------------------------------------------------------------------------------------------------------------
$receiver_email = $_POST['receiver_email'];
if ($receiver_email != $paypal_account_email) {
    exit();
}
// Check number 2 ------------------------------------------------------------------------------------------------------------
if ($_POST['payment_status'] != "Completed") {
exit();
}
$directory = $cart_database_path."sales/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}
$transid = $_POST['custom'];
$sales = $directory.$transid.".json";
if (!file_exists($sales)){
	exit();
}

$salesByCode = json_decode(file_get_contents($sales), true);
if($_POST['mc_gross'] == $salesByCode["amount"]){
$thisSales = array('code'=>$transid, 'amount'=>$salesByCode["amount"], 'status'=>"Paid", 'day'=>$salesByCode["day"],'pro'=>$salesByCode["pro"],'pcode'=>$salesByCode["pcode"],'cname'=>$salesByCode["cname"], 'phone'=>$salesByCode["phone"], 'email'=>$salesByCode["email"], 'add'=>$salesByCode["add"]);
$thisSales = json_encode($thisSales);
file_put_contents($directory.$transid.".json",$thisSales);
$dtnow = @date('d/m/Y h:i:s A');
$trackinfo = "<hr><p><b>".$dtnow." :&nbsp;</b>A Payment  of ".@$salesByCode['pcode'].number_format($_POST['mc_gross'], 2)." was recieved Via Our  ".@$salesByCode["pro"]." payment processor Terminal and the Status of the payment is ".$_POST['payment_status']."</p><hr>";
file_put_contents($cart_database_path."track/".$transid.".txt", $trackinfo, FILE_APPEND);
$order	=  json_decode(file_get_contents($cart_database_path."orders/".$transid.".json"), true);
foreach ($order as $item){
$product	=  json_decode(file_get_contents($cart_database_path."products/".$item['code'].".json"), true);	
if($product["digital-d"] != "")
{
$dtnow = @date('d/m/Y h:i:s A');
$trackinfo = "<hr><p><b>".$dtnow." :&nbsp;</b>".$product["pname"]." Was enabled for you to download. <a target='_blank' href='".$product['digital-d']."'>Click Here to start downloading</a>.</p><hr>";
file_put_contents($cart_database_path."track/".$transid.".txt", $trackinfo, FILE_APPEND);	
}
}
exit;
}
?>