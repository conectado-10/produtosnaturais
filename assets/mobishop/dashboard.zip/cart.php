<?php
session_start();
require_once("./setup.php");
$tot = "";

$settings	=  json_decode(file_get_contents($cart_database_path."settings/data.json"), true);
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
	$product = $cart_database_path."products/".trim($_GET["code"]).".json";
if(!file_exists($product)){
//noting product matched your ID
}else{
$productByCode = json_decode(file_get_contents($product), true);	



		if(!empty($_GET["quantity"])) {
			$itemArray = array($productByCode["code"]=>array('name'=>$productByCode["pname"], 'code'=>$productByCode["code"], 'quantity'=>$_GET["quantity"], 'price'=>$productByCode["price"],'vat'=>$productByCode["ptax"],'shipping'=>$productByCode["pshipping"]));
			
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode["code"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($productByCode["code"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_GET["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}
?>

<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>MobiShp v1.0.1 Shopping Cart</title>
<link href="css/style.css?v=01" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="shopping-cart">
<div class="txt-heading">Shopping Cart</div>

<a id="btnEmpty" href="cart.php?action=empty">Empty Cart</a>
<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
	$total_vat = 0;
	$total_shipping = 0;

?>	
<table class="tbl-cart" cellpadding="10" cellspacing="1">
<thead>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:right;" width="5%">Qty</th>
<th style="text-align:right;" width="15%">Price</th>
<th style="text-align:right;" width="15%">Total</th>
<th style="text-align:center;" width="10%">Remove</th>
</tr>
</thead>	
<tbody>
<?php		
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
				<tr>
				<td><?php echo $item["name"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo $settings["picon"]."".number_format($item["price"],2); ?></td>
				<td  style="text-align:right;"><?php echo $settings["picon"]."". number_format($item_price,2); ?></td>
				<td style="text-align:right;"><a href="cart.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction"><img src="images/icon-delete.png" alt="Remove Item" /></a></td>
				</tr>
				<?php
				$total_vat += $item["vat"]*$item["quantity"];
				$total_shipping += ($item["shipping"]*$item["quantity"]);
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>
<?php
if($total_vat > 0){
?>
<tr>
<td align="right" colspan="5"><strong>Vat:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $settings["picon"]."".number_format($total_vat, 2); ?></strong></td>
</tr>
<?php
}
?>
<?php
if($total_shipping > 0){
if($total_price > $settings["fsa"]){
$total_shipping = 0.00;
$gtotal_shipping = "Free";
}elseif($total_shipping > $settings["msc"]){
$total_shipping = $settings["msc"];
$gtotal_shipping = $settings["picon"]."".number_format($total_shipping, 2);
}else{
$total_shipping = $total_shipping;
$gtotal_shipping = $settings["picon"]."".number_format($total_shipping, 2);	
}

?>
<tr>
<td align="right" colspan="5"><strong>Shipping:&nbsp;&nbsp;&nbsp;<?php echo $gtotal_shipping; ?></strong></td>
</tr>
<?php
}
if($settings["ptax"] == "In.vat"){
$gtotal = $total_price + $total_vat;
$tot = $settings["ptax"];
}elseif($settings["ptax"] == "Ex.vat"){
$tot = $settings["ptax"];
$gtotal = $total_price;
}else{
$tot = "";	
$gtotal = $total_price;
}

?>
<tr>
<td align="right" colspan="5"><strong>Total:&nbsp;&nbsp;&nbsp;<?php echo $settings["picon"]."".number_format($gtotal, 2); ?>&nbsp;&nbsp;<span style="color: red"><?php echo $tot; ?></span></strong></td>

</tr>
</tbody>
</table>
<a id="Checkoutbtn" href="#checkout" onclick="Showcheckout()">Checkout</a>
  <?php
} else {
?>
<div class="no-records">Your Cart is Empty</div>
<?php 
}
?>

</div>

<div id="customer-information" style="display: none">
<div class="txt-heading">Customer Information</div>
<a id="Backbtn" href="#checkout" onclick="Showcart()">Back to Cart</a>
<form target="_blank" action="./payment_processor/<?php echo $settings["papi"];?>/index.php" method="post" class="form-checkout">
                 <input type="hidden" name="total_amount" value="<?php echo $total_price; ?>">
				 <input type="hidden" name="vat" value="<?php echo $total_vat; ?>">
				 <input type="hidden" name="shipping" value="<?php echo $total_shipping; ?>">
				 <input type="hidden" name="pro" value="<?php echo $settings["papi"]; ?>">
				 <input type="hidden" name="procode" value="<?php echo $settings["pcode"]; ?>">
				 <input type="hidden" name="proicon" value="<?php echo $settings["picon"]; ?>">
	   <table class="tbl-cart" cellpadding="10" cellspacing="1" border="0" width="100%"> 
<tr>	   
<td  style="text-align:left;">
                            <label for="name" class="form-control-label">Name</label>
                            <input type="text" name="name" required="required" class="form-control">
</td>
<td  style="text-align:left;">
                            <label for="email" class="form-control-label">Email</label>
                            <input type="email" name="email" required="required" class="form-control">
</td>
</tr>
<tr>
<td  style="text-align:left;">
                            <label for="phone" class="form-control-label">Phone</label>
                            <input type="tel" name="phone" required="required" class="form-control">
</td>
<td  style="text-align:left;">
                            <label for="address" class="form-control-label">Address</label>
                            <input type="text" name="address" required="required" class="form-control">
</td>
</tr>
<tr>
<td style="text-align:left;">
<img src="payment_processor/<?php echo $settings["papi"];?>/<?php echo $settings["papi"];?>.png"  style="min-width: 250px;max-width: 300px; width: 100%; height: auto">
</td>
<td style="text-align:right;">
<input type="image" src="payment_processor/<?php echo $settings["papi"];?>/<?php echo $settings["papi"];?>-button.png" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
</td>
</tr>
</table>
</form>
</div>
<br><br><br><br><br>
<script>
function Showcheckout(){
document.getElementById("shopping-cart").style.display = 'none';
document.getElementById("customer-information").style.display = 'block';
}
function Showcart(){
document.getElementById("customer-information").style.display = 'none';
document.getElementById("shopping-cart").style.display = 'block';
}
</script>
</body>
</html>