<?php
require("./setup.php");
if($_GET["type"] == "payfast"){
require_once("payfast_ipn.php");
}elseif($_GET["type"] == "paypal"){
require_once("paypal_ipn.php");
}elseif($_GET["type"] == "paystack"){
require_once("paystack_webhook.php");
}else{
echo "No Information to process";
exit;
}
?>