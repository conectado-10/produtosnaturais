<?php
//Bulk SMS Configuration variable
$bulksms_api_url = @$settings["smsurl"]
$bulksms_username = @$settings["smsuvn"];
$bulksms_password = @$settings["smspvn"];
$bulksms_senderid = @$settings["smssivn"];
$seller_phone_number = @$settings["smstelevn"];
$message_content = "A New order have been placed on your website by ". @$name[0]." ".@$name[1]." With order value of ".$_POST["proicon"].number_format($amt, 2)."You can track the transaction using: ". $transid;

//Bulk SMS Curl Request Setup
if(@$settings["smsencode"] == "Yes"){
$data = @$settings["smsuvan"]."=".$bulksms_username."&".@$settings["smspvan"]."=".$bulksms_password."&".@$settings["smssivan"]."=".urlencode($bulksms_senderid)."&".@$settings["smsvnm"]."=".urlencode($message_content)."&".@$settings["smstelevan"]."=".$seller_phone_number;
$data_string = json_encode($data);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$bulksms_api_url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json','Content-Length: ' . strlen($data_string)));
$pushsms = curl_exec ($ch);
curl_close ($ch);
}else{
$data = @$settings["smsuvan"]."=".$bulksms_username."&".@$settings["smspvan"]."=".$bulksms_password."&".@$settings["smssivan"]."=".urlencode($bulksms_senderid)."&".@$settings["smsvnm"]."=".urlencode($message_content)."&".@$settings["smstelevan"]."=".$seller_phone_number;
$data_string = $data;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$bulksms_api_url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$pushsms = curl_exec ($ch);
curl_close ($ch);	
	
}

?>