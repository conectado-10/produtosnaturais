<?php
session_start();
error_reporting(0);
set_time_limit(0);
ob_start();
include "../setup.php";
$dashbard_database_path = $dashbard_database_path;
$cart_database_path = $cart_database_path;
$payment_processor_database_path = $payment_processor_database_path;
if(!isset($_SESSION["loggedin"]))
{
	exit;
}
?>