<?php
session_start();
require_once("../../setup.php");
//You Cant Access Page Direct.
if(empty($_POST)){
header("Location: ../../../");
exit();
}
$settings	=  json_decode(file_get_contents($payment_processor_database_path."settings/data.json"), true);
$name = @$_POST["name"];
$name = explode(" ", $name);
require_once("./saveorder.php");
$transact_id = $transid;
//Paystack publick key
$paystack_public_key = $paystack_public_key;
//Paystack success url
$paystack_success_url = $paystack_success_url;
//Paystack cancel url
$paystack_close_url = $paystack_close_url;
//Paystack Account email
$paystack_account_email = $paystack_account_email;
//Paying for
$payment_desc = "Paying for the product purched from our shop with transaction ID ".$transact_id;
 ?>
<!DOCTYPE html>
 <html>
 <head>
  <meta charset="UTF-8">
  <title>Paystack Payment Processing Gateway</title>
</head>
 <body>
<form  method="POST" id="jsform">
<input type="hidden" id="payername" value="<?php echo $_POST["name"];?>">
<input type="hidden" id="paymentdesc" value="<?php echo @$payment_desc;?>">
<?php
	
$string = $amt;
$amt = str_replace('.', '', $string);
?>
<input type="hidden" name="amount" id="paidamt" value="<?php echo $amt;?>">	
<input type="hidden" id="payerphone" value="<?php echo $_POST["phone"];?>">
<input type="hidden" id="ppcode" value="<?php echo $transact_id;?>">
<input type="hidden" id="pdate" value="<?php echo @date("Y-m-d");?>">
</form>
<script src="https://js.paystack.co/v1/inline.js"></script>
<script type="text/javascript">
function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: "<?php echo $paystack_public_key;?>",
      email: "<?php echo $paystack_account_email;?>",
      amount: parseInt(document.getElementById("paidamt").value),
      currency: "<?php echo $settings['pcode'];?>",
      ref: "<?php echo $transact_id;?>", // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      metadata: {
         custom_fields: [
            {
                display_name: "Payer Name",
                variable_name: "pname",
                value: document.getElementById("payername").value,
            },
            {
				display_name: "Payer Phone",
                variable_name: "pphone",
                value: document.getElementById("payerphone").value,
            },
            {
				display_name: "Payment Desc",
                variable_name: "pd",
                value: document.getElementById("paymentdesc").value,
            },
            {
				display_name: "Payment Date",
                variable_name: "pdate",
                value: document.getElementById("pdate").value,
            },
            {
				display_name: "Payer ID",
                variable_name: "pid",
                value: document.getElementById("ppcode").value,
            }
         ]
      },
      callback: function(response){
		  setTimeout(function() {
  alert('success. transaction ref is ' + response.reference);
		  window.location.href="<?php echo @$paystack_success_url;?>";
		  console.log(response);
    }, 4000);
        
      },
      onClose: function(){
		  window.location.href="<?php echo @$paystack_close_url;?>";
      }
    });
    handler.openIframe();
  }
payWithPaystack();
</script>
</body>
</html>