<?php
include_once('../../setup.php');
if(!empty($_POST))
{
function tid($length = 15) {
    return substr(str_shuffle(str_repeat($x='23456789ABCDEFGHJKLMNPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
$transid = tid();
$directory = $payment_processor_database_path."sales/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}
$directory2 = $payment_processor_database_path."customers/";
if (!is_dir($directory2)) {
    mkdir($directory2, 0777, true);
}
$directory3 = $payment_processor_database_path."orders/";
if (!is_dir($directory3)) {
    mkdir($directory3, 0777, true);
}
$directory4 = $payment_processor_database_path."track/";
if (!is_dir($directory4)) {
    mkdir($directory4, 0777, true);
}
$thisProductArray = array();
foreach ($_SESSION["cart_item"] as $item){
$thisProduct = array('pname'=>$item["name"], 'code'=>$item["code"], 'quantity'=>$item["quantity"], 'price'=>$item["price"],'vat'=>$item["vat"],'shipping'=>$item["shipping"]);
$thisProductArray[] = $thisProduct;
}
$thisProductArray = json_encode($thisProductArray);
file_put_contents($directory3.$transid.".json",$thisProductArray);
$dates = @date("d/m/Y");
$amt = $_POST["total_amount"] + $_POST["vat"] + $_POST["shipping"];
$thisSales = array('code'=>$transid, 'amount'=>$amt, 'status'=>"Not paid", 'day'=>$dates,'pro'=>$_POST["pro"],'pcode'=>$_POST["procode"],'cname'=>$_POST["name"], 'phone'=>$_POST["phone"], 'email'=>$_POST["email"], 'add'=>$_POST["address"]);
$thisSales = json_encode($thisSales);
file_put_contents($directory.$transid.".json",$thisSales);

$cu_code = strtoupper(@$_POST["email"]);
$cu_code = md5($cu_code);
$thisCustomer = array('code'=>$cu_code,'cname'=>$_POST["name"], 'phone'=>$_POST["phone"], 'email'=>$_POST["email"], 'add'=>$_POST["address"]);
$thisCustomer = json_encode($thisCustomer);
file_put_contents($directory2.$cu_code.".json",$thisCustomer);
include('../../sendemail.php');
}else{
$msg = "Request Not Understood";
echo $msg;
exit;
}

?>